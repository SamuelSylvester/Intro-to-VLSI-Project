DFF_MS contains:
-Given schematic, with power sources, ground and capacitor removed
-symbol of D Flip Flop (DFF)

DFF_MS_Sim contains:
-DFF_pcq_Time: Schematic using DFF symbol for use with stimulation state c2q
-DFF_Setup_Time: Schematic using DFF symbol for use with stimulation state T_setup
-DFF_Test: Schematic using DFF symbol for use with stimulation state DFF_Functionality_Test

The D Flip Flop testing was done using the schematics in the DFF_MS_Sim folder, which uses the symbol from the DFF_MS folder. Each test was setup to use the saved state corresponding to the same of the schematic, where the points of interest that were used to find the data are marked.

States are saved in the DFF_MS_Sim_States Folder.

